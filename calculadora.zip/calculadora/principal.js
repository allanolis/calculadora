// Funções matemáticas
function soma(a, b) {
    return a + b;
  }
  
  function subtracao(a, b) {
    return a - b;
  }
  
  function multiplicacao(a, b) {
    return a * b;
  }
  
  function divisao(a, b) {
    return a / b;
  }
  
  function potencia(base, expoente) {
    return Math.pow(base, expoente);
  }
  
  function raizQuadrada(num) {
    return Math.sqrt(num);
  }
  
  // Função principal da calculadora
  function calcular() {
    var operacao = prompt("Digite a operação desejada (+, -, *, /, ^, raiz):");
  
    // Verifica a operação selecionada
    switch (operacao) {
      case "+":
        var num1 = parseFloat(prompt("Digite o primeiro número:"));
        var num2 = parseFloat(prompt("Digite o segundo número:"));
        var resultado = soma(num1, num2);
        alert("Resultado: " + resultado);
        break;
  
      case "-":
        var num1 = parseFloat(prompt("Digite o primeiro número:"));
        var num2 = parseFloat(prompt("Digite o segundo número:"));
        var resultado = subtracao(num1, num2);
        alert("Resultado: " + resultado);
        break;
  
      case "*":
        var num1 = parseFloat(prompt("Digite o primeiro número:"));
        var num2 = parseFloat(prompt("Digite o segundo número:"));
        var resultado = multiplicacao(num1, num2);
        alert("Resultado: " + resultado);
        break;
  
      case "/":
        var num1 = parseFloat(prompt("Digite o primeiro número:"));
        var num2 = parseFloat(prompt("Digite o segundo número:"));
        var resultado = divisao(num1, num2);
        alert("Resultado: " + resultado);
        break;
  
      case "^":
        var base = parseFloat(prompt("Digite a base:"));
        var expoente = parseFloat(prompt("Digite o expoente:"));
        var resultado = potencia(base, expoente);
        alert("Resultado: " + resultado);
        break;
  
      case "raiz":
        var num = parseFloat(prompt("Digite o número:"));
        var resultado = raizQuadrada(num);
        alert("Resultado: " + resultado);
        break;
  
      default:
        alert("Operação inválida.");
        break;
    }
  }
  
  // Chamada da função principal
  calcular();
  